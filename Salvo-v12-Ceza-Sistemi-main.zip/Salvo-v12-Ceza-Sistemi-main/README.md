# Salvo-v12-Ceza-Sistemi
Dostlarım v12 Discord Ceza ve Sicil Sistemi Altyapısını Sizin için Hazırladım. Herhangi Bir Sorun ile Karşılaşırsanız Safe Code Discord Sunucumuza Gelerek Destek Alabilirsiniz. İyi Kodlamalar :) 
